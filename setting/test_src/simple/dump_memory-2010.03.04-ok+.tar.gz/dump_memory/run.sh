#!/bin/sh
/usr/local/arm/4.2.2-eabi/usr/bin/arm-linux-gcc -Wall -o dump_memory.a8.glibc dump_memory.c
gcc -Wall -o dump_memory.x86 dump_memory.c
/opt/arm/usr/bin/arm-linux-gcc -Wall -o dump_memory.arm11.uclibc dump_memory.c
/opt/4.3.2-eabi-arm/bin/arm-linux-gcc -Wall -o dump_memory.arm.glibc dump_memory.c
/usr/local/arm/gcc-4.0.2-glibc-2.3.6/arm-softfloat-linux-gnu/bin/arm-softfloat-linux-gnu-gcc -Wall -o dump_memory.arm.glibc.abi dump_memory.c
cp dump_memory.arm11.uclibc /home/kskim/nfsroot/md


