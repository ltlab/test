#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <signal.h>



#define MAP_SIZE	0x1000
#define ASCII_START     0x20
#define ASCII_END	0x7E

volatile void *map_base;
unsigned int buffer_physical = 0, buffer_offset = 0 , buffer_number = 0;

int main (int argc, char *argv[])
{
	int fd;
	unsigned int result = 0;
	int i, j;
	unsigned int tmp_physical , tmp_offset , tmp_number ;
	unsigned int tmp_physical2, tmp_offset2, tmp_number2; 
	unsigned char tmp_byte1, tmp_byte2, tmp_byte3, tmp_byte4;

	// usage
	if (argc <= 1) {
		printf("\nUsage : dump_memory [Pysical Address] [Offset Address] [# of Objects]");
		printf("\n        [Pysical Address] = 0 ~ 0xFFFFF000");
		printf("\n        [Address Offset]  = 0 ~ 0xFFC");
		printf("\n        [# of Objects]    = 0 ~ 256");
		printf("\n   ex)  dump_memory 0x20000000 0x0A3 4");
		printf("\n   ex)  dump_memory 20000000   0A3");
		printf("\n   ex)  dump_memory 20000000\n");

		return -1;
	}


	// parse parameters
	if((argv[1][0] == '0') && ((argv[1][1] == 'x') || argv[1][1] == 'X')){
		buffer_physical = strtoll(&argv[1][2], NULL, 16);
	}
	else {
		buffer_physical = strtoll(&argv[1][0], NULL, 16);
	}
	printf("\nPhysical Address = 0x%08x", buffer_physical);

	if (argc >= 3){
		if((argv[2][0] == '0') && ((argv[2][1] == 'x') || argv[2][1] == 'X')){
			buffer_offset = strtoll(&argv[2][2], NULL, 16);
		}
		else {
			buffer_offset = strtoll(&argv[2][0], NULL, 16);
		}
		printf("\nOffset Address   = 0x%08x", buffer_offset);
	}

	if (argc >= 4){
		buffer_number = strtoll(&argv[3][0], NULL, 10);
	}
	else {
		buffer_number = 1;
	}


	// check range
	if (buffer_offset >= 0xffc){
		printf("\nWrong [Offset Address] range !\n");

		return -1;
	}
	if (buffer_number > 256){
		printf("\nWrong [Number of Objects] range !\n");

		return -1;
	}


	// memory open & mmap
	fd = open( "/dev/mem", O_RDWR | O_SYNC );
	if (fd == -1) {
		perror("open(\"/dev/mem\")");
		exit(1);
	}

	map_base = mmap( NULL, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, buffer_physical);
	if (map_base == MAP_FAILED) {
		perror("mmap()");
		exit(2);
	}

	// display memory area
	tmp_physical = buffer_physical; tmp_offset = buffer_offset; tmp_number = buffer_number;
	tmp_physical2= buffer_physical; tmp_offset2= buffer_offset; tmp_number2= buffer_number;
	
	for(i = 0;i < buffer_number; i+=4){
		printf("\n%08x: ", tmp_physical);
		for(j = 0; j < 4; j++){
			result = (*((volatile unsigned int *)(map_base + tmp_offset))); 
			printf("%08x ", result);
			tmp_offset += 4;
		}

		// display ascii character
		for(j = 0; j < 4; j++){
			result = (*((volatile unsigned int *)(map_base + tmp_offset2)));
			tmp_byte1 = (unsigned char)(result >> 24) & 0xff;
			tmp_byte2 = (unsigned char)(result >> 16) & 0xff;
			tmp_byte3 = (unsigned char)(result >>  8) & 0xff;
			tmp_byte4 = (unsigned char)(result >>  0) & 0xff;

			// convert non-readable character to '.'
			if ((tmp_byte1 < ASCII_START) || (tmp_byte1 > ASCII_END)){
				tmp_byte1 = '.';
			}
			if ((tmp_byte2 < ASCII_START) || (tmp_byte2 > ASCII_END)){
				tmp_byte2 = '.';
			}
			if ((tmp_byte3 < ASCII_START) || (tmp_byte3 > ASCII_END)){
				tmp_byte3 = '.';
			}
			if ((tmp_byte4 < ASCII_START) || (tmp_byte4 > ASCII_END)){
				tmp_byte4 = '.';
			}

			// trick : originally you must input even buffer_number
			if ((buffer_number % 2) == 0){
				printf(" %c%c%c%c", tmp_byte1, tmp_byte2, tmp_byte3, tmp_byte4);
			}
			else{
				printf(" %c%c%c%c", tmp_byte4, tmp_byte3, tmp_byte2, tmp_byte1);
			}
			tmp_offset2 += 4;
		}
		tmp_physical += 0x10;
	}
	printf("\n");

	// release resources
	if (munmap((void *)map_base, (size_t)MAP_SIZE) == -1) {
		perror("munmap()");
		exit(3);
	}

	close(fd);

	return 0;
}

