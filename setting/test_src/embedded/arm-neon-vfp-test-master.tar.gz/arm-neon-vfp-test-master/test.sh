#!/bin/sh

ARGS="2.200002 2.200001 5"

./soft $ARGS
./soft-vector $ARGS
./softfp-vfp $ARGS
./softfp-neon $ARGS
./softfp-neon-vector $ARGS
./softfp-neon-vector-unsafe $ARGS
./hard $ARGS
./hard-vector $ARGS
./hard-vector-unsafe $ARGS
./default $ARGS
